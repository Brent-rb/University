#ifndef POINTLIGHT_H
#define POINTLIGHT_H
#include "Vec3.h"
#include "RGB_Color.h"

class PointLight
{
public:
    PointLight();
    PointLight(Vec3 position, RGB_Color light): $light(light), $position(position) {}

    void setPosition(Vec3 position) { $position = position; }
    void setColor(RGB_Color color) { $light = color; }

    RGB_Color getColor() { return $light; }
    Vec3 getPosition() { return $position; }

private:
    Vec3 $position;
    RGB_Color $light;
};

#endif // POINTLIGHT_H
