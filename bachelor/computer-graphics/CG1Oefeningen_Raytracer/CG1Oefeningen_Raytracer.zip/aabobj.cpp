#include "aabobj.h"


AABObj::AABObj() {

}

void AABObj::SetCorners(Vec3 leftLower, Vec3 rightUpper) {
    $lowerLeftBack = leftLower;
    $upperRightFront = rightUpper;
}

void AABObj::getIntersection(Ray* ray, ReturnObject* returnObject) {
    double tZUpper, tZLower;
    double tXFront, tXBack;
    double tYLeft, tYRight;
    double smallest;
    bool foundOne = false;

    Vec3 intersection;
    Vec3 smallestIntersection;
    Vec3 normal;
    Vec3 rayOrg = ray->getOrigin();
    Vec3 rayDir = ray->getDirection();

    tZUpper = ($upperRightFront.z - rayOrg.z) / rayDir.z;
    tZLower = ($lowerLeftBack.z - rayOrg.z) / rayDir.z;
    tXFront = ($upperRightFront.x - rayOrg.x) / rayDir.x;
    tXBack = ($lowerLeftBack.x - rayOrg.x) / rayDir.x;
    tYLeft = ($lowerLeftBack.y - rayOrg.y) / rayDir.y;
    tYRight = ($upperRightFront.y - rayOrg.y) / rayDir.y;

    intersection = rayOrg + (rayDir * tZUpper);
    if(isInside(intersection)) {
        foundOne = true;
        smallest = tZUpper;
        smallestIntersection = intersection;
    }

    intersection = rayOrg + (rayDir * tZLower);
    if(isInside(intersection)) {
        if(!foundOne || (smallest > tZLower)) {
            foundOne = true;
            smallest = tZLower;
            smallestIntersection = intersection;
            normal = Vec3(0, 0, -1);
        }
    }

    intersection = rayOrg + (rayDir * tXFront);
    if(isInside(intersection)) {
        if(!foundOne || (smallest > tXFront)) {
            foundOne = true;
            smallest = tXFront;
            smallestIntersection = intersection;
        }
    }

    intersection = rayOrg + (rayDir * tXBack);
    if(isInside(intersection)) {
        if(!foundOne || (smallest > tXBack)) {
            foundOne = true;
            smallest = tXBack;
            smallestIntersection = intersection;
        }
    }

    intersection = rayOrg + (rayDir * tYLeft);
    if(isInside(intersection)) {
        if(!foundOne || (smallest > tYLeft)) {
            foundOne = true;
            smallest = tYLeft;
            smallestIntersection = intersection;
        }
    }

    intersection = rayOrg + (rayDir * tYRight);
    if(isInside(intersection)) {
        if(!foundOne || (smallest > tYRight)) {
            foundOne = true;
            smallest = tYLeft;
            smallestIntersection = intersection;
        }
    }

    if(foundOne) {
        returnObject->setIntersectionFound(true);
        returnObject->setIntersectionPoint(smallestIntersection);
        returnObject->setDistance(smallest);
        //returnObject->setNormal();
    }
    else {
        returnObject->setIntersectionFound(false);
    }
}

Vec3 AABObj::getLowerLeft() {
    return $lowerLeftBack;
}

Vec3 AABObj::getUpperRight() {
    return $upperRightFront;
}

bool AABObj::isInside(Vec3 position) {
    if(position.x >= $lowerLeftBack.x && position.x <= $upperRightFront) {
        if(position.y >= $lowerLeftBack.y && position.y <= $upperRightFront) {
            if(position.z >= $lowerLeftBack.z && position.z <= $upperRightFront.z) {
                return true;
            }
        }
    }

    return false;
}
