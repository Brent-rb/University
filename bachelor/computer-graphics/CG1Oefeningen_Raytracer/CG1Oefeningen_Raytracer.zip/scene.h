#ifndef SCENE_H
#define SCENE_H
#include "ShapeList.h"
#include "Vec3.h"
#include "pointlightlist.h"

class Scene
{
public:
    Scene(Vec3 eye, ShapeList* shapeList, PointLightList* lights);
    ~Scene();

    void addShape(Shape* shape) { $shapeList->AddShape(shape); }
    void clear();

    Vec3 getEye() { return $eye; }
    ShapeList* getShapeList() { return $shapeList; }

private:
    ShapeList* $shapeList;
    PointLightList* $lights;
    Vec3 $eye;
};

#endif // SCENE_H
