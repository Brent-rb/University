#include "pointlight.h"

PointLight::PointLight()
{

}

